//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <routingProtocol.h>
#include "GLOBALS.h"
#include "ApplicationLayer.h"

routingProtocol::routingProtocol(cSimpleModule *m,cMessage *s) {
    this->module=m;
    this->scheduledEvent=s;
    // TODO Auto-generated constructor stub

}

routingProtocol::~routingProtocol() {
    // TODO Auto-generated destructor stub
}

void routingProtocol::sendNewPacket(float data){
    if (parent==255) return;
    Packet *pkt=new Packet(module->getName());
    pkt->setDstAddress(parent);
    pkt->setSndAddress(address);
    pkt->setHopCount(hopCount);
    pkt->setData(0,data);
    pkt->setDataSrc(0,address);
    pkt->setMsgCount(1);
    for (int i=0;i<module->gateSize("gate$o");i++){
        module->send(pkt->dup(),"gate$o",i);
    }
    delete pkt;
}

void routingProtocol::handleMyPacket(Packet *pkt){
    if (parent==255){return;}
    unsigned char MsgCount=pkt->getMsgCount();
    float data=ApplicationLayer::generateData();
    pkt->setSndAddress(address);
    pkt->setDstAddress(parent);
    pkt->setHopCount(hopCount);
    if (MsgCount<MAX_MSG_COUNT){
        pkt->setData(MsgCount,data);
        pkt->setDataSrc(MsgCount,address);
        pkt->setMsgCount(MsgCount+1);
        module->cancelEvent(scheduledEvent);
        ApplicationLayer::scheduleNextEvent(module,scheduledEvent);
    }
    for (int i=0;i<module->gateSize("gate$o");i++){
        module->send(pkt->dup(),"gate$o",i);
    }
}

void routingProtocol::handleOverHeard(Packet *pkt){
    if (pkt->getHopCount()<hopCount){
        hopCount=pkt->getHopCount()+1;
        parent=pkt->getSndAddress();
    }
}


