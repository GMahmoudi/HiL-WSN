//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <HybridNode.h>
#include <random.h>
#include <algorithm> //find , needs std namespace

using namespace std;

HybridNode::HybridNode() {
    // TODO Auto-generated constructor stub

}

HybridNode::~HybridNode() {
    // TODO Auto-generated destructor stub
    cancelAndDelete(rtEvent);
}

void HybridNode::initialize(){
    rtEvent = new cMessage("rtEvent");
    rtScheduler = check_and_cast<cSocketRTScheduler *>(simulation.getScheduler());
    rtScheduler->setInterfaceModule(this, rtEvent, recvBuffer, 4000, &numRecvBytes);
    EV<<"listening...";
}

void HybridNode::SendRawPkt(Packet *pkt){
    char rawPkt[32]={0};
    unsigned char MsgCount=pkt->getMsgCount();
    rawPkt[0]=pkt->getSndAddress();
    rawPkt[1]=pkt->getDstAddress();
    rawPkt[2]=pkt->getHopCount();
    rawPkt[3]=MsgCount;
    for (int i=0;i<MsgCount;i++){
        float f=pkt->getData(i);
        memcpy(rawPkt+4+4*i,&f,4);
    }
    for (int i=0;i<MsgCount;i++){
        rawPkt[MAX_MSG_COUNT*4+4+i]=pkt->getDataSrc(i);
    }
    try{
        rtScheduler->sendBytes(rawPkt,32);
    }
    catch (cRuntimeError e){
        EV<<"error sending the raw packet"<<endl;
    }
}

void HybridNode::parsePacket(Packet *pkt){
    pkt->setSndAddress(recvBuffer[0]);
    pkt->setDstAddress(recvBuffer[1]);
    pkt->setHopCount(recvBuffer[2]);
    if (recvBuffer[3]>MAX_MSG_COUNT){
        EV<<"invalid packet msg count is "<<int(recvBuffer[3])<<endl;
        return;
    }
    pkt->setMsgCount(recvBuffer[3]);
    for(int i = 0;i<recvBuffer[3];i++){
        char t[4];
        float f;
        for (int j=0;j<4;j++){
            t[j]=recvBuffer[j+4*i+4];
        }
        memcpy(&f, &t, 4);
        pkt->setData(i,f);
    }
    for(int i=0;i<recvBuffer[3];i++){
        pkt->setDataSrc(i,recvBuffer[4+MAX_MSG_COUNT*4+i]);
    }
    numRecvBytes=0;
}

void HybridNode::handleMessage(cMessage *msg){
        Packet *pkt=new Packet();
        if (strcmp("rtEvent",msg->getName())==0){
            pkt = new Packet("parsedpkt");
            parsePacket(pkt);
            EV<<"rtEvent at time "<<simTime()<<" sender is "<<int(pkt->getSndAddress())<<" parent is "<<int(pkt->getDstAddress())<<endl;
            for (int i=0;i<gateSize("vGate$o");i++){
                send(pkt->dup(),"vGate$o",i);
            }
            bubble("HW pkt");
            delete pkt;
        }
        else if(msg->arrivedOn("vGate$i")){
            pkt = check_and_cast<Packet *>(msg);
            SendRawPkt(pkt);
            delete pkt;
            return;
        }
        else{
            delete pkt;
        }
}
