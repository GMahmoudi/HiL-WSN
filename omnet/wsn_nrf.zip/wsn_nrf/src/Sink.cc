//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <Sink.h>
#include <ctime>

long double STARTTIME;
Sink::Sink() {
    // TODO Auto-generated constructor stub
    sinkSocket=socket(AF_INET, SOCK_DGRAM, 0);
    // setting timeout of recvfrom function to 10us
    struct timeval timeout;
    timeout.tv_sec=0;
    timeout.tv_usec=10;
    setsockopt(sinkSocket,SOL_SOCKET,SO_RCVTIMEO,(char *)&timeout,sizeof(struct timeval));
    // server socket info
    sockaddr_in sinInterface;
    sinInterface.sin_addr.s_addr=INADDR_ANY;
    sinInterface.sin_family=AF_INET;
    sinInterface.sin_port=htons(SINK_PORT);
    if (bind(sinkSocket, (sockaddr*)&sinInterface, sizeof(sockaddr_in))==SOCKET_ERROR)
        throw cRuntimeError("cSocketRTScheduler: socket bind() failed");

    // initiate client address to NONE
    client.sin_addr.s_addr=INADDR_NONE;
}

Sink::~Sink() {
    // TODO Auto-generated destructor stub
}

void Sink::sendRawPkt(Packet *pkt,sockaddr_in &sockaddress){
    char rawPkt[32]={0};
    int rawPktLen=32;
    unsigned char MsgCount=pkt->getMsgCount();
    int sockaddrlen=sizeof(sockaddress);
    rawPkt[0]=pkt->getSndAddress();
    rawPkt[1]=pkt->getDstAddress();
    rawPkt[2]=pkt->getHopCount();
    rawPkt[3]=MsgCount;
    for (int i=0;i<MsgCount;i++){
        float f=pkt->getData(i);
        memcpy(rawPkt+4+4*i,&f,4);
    }
    for (int i=0;i<MsgCount;i++){
        rawPkt[MAX_MSG_COUNT*4+4+i]=pkt->getDataSrc(i);
    }
    sendto(sinkSocket,rawPkt,rawPktLen,0,(struct sockaddr *) &sockaddress, sockaddrlen);
}

void Sink::handshake(sockaddr_in &sockaddress){
    char buf[4]={0};
    int BUFSIZE=4;
    int sockaddrlen=sizeof(sockaddress);
    int n=recvfrom(sinkSocket,buf,BUFSIZE,0,(struct sockaddr *) &sockaddress,&sockaddrlen);
    if (n>0) EV<<"client connected !!\n";
}

void Sink::broadcast(){
    Packet *pkt=new Packet("init");
    pkt->setSndAddress(address);
    pkt->setHopCount(0);
    pkt->setDstAddress(BROADCAST);
    for (int i=0;i<gateSize("gate$o");i++){
        send(pkt->dup(),"gate$o",i);
    }
    delete pkt;
}
void Sink::initialize(){
    address=par("addr");
    //broadcast();
    cMessage *msg=new cMessage("RealTimeStart");
    scheduleAt(simTime(),msg);
    msg=new cMessage("sinkInit");
    scheduleAt(simTime()+5,msg);
    scheduleAt(simTime()+10,msg->dup());
    scheduleAt(simTime()+15,msg->dup());
    scheduleAt(simTime()+20,msg->dup());
    scheduleAt(simTime()+25,msg->dup());
    scheduleAt(simTime()+30,msg->dup());
}
void Sink::handleMessage(cMessage *msg){
    if (strcmp("sinkInit",msg->getName())==0){broadcast();return;}
    else if (strcmp("RealTimeStart",msg->getName())==0) {STARTTIME=time(0);return;}
    Packet *pkt = check_and_cast<Packet *>(msg);
    if (pkt->getMsgCount()==0){
        EV<<"msg count 0 from "<<int(pkt->getDataSrc(0))<<" its hopCount is "<<int(pkt->getHopCount())<<" data "<<pkt->getData(0);
    }
    for (int i=0;i<pkt->getMsgCount();i++){
        EV<<"data : "<<pkt->getData(i)<<" ,data src : "<<int(pkt->getDataSrc(i))<<" msg count "<<int(pkt->getMsgCount())<<" ,at time "<<simTime()<<" real time is: "<<time(0)-STARTTIME<<endl;
        if (par("exposeToInternet")){
            if (client.sin_addr.s_addr==INADDR_NONE){
                handshake(client);
                sendRawPkt(pkt,client);
            }
            else{
                sendRawPkt(pkt,client);
            }
        }
    }
    delete msg;
}
