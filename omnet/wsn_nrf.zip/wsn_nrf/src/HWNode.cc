//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <HWNode.h>

HWNode::HWNode() {
    // TODO Auto-generated constructor stub

}

HWNode::~HWNode() {
    // TODO Auto-generated destructor stub
}
void HWNode::initialize(){
    address=par("addr");
}
void HWNode::handleMessage(cMessage *msg){
    Packet *pkt = check_and_cast<Packet *>(msg);
    if (msg->arrivedOn("gate$i")){
        if (pkt->getDstAddress()==address){
            send(pkt->dup(),"vGate$o",0);
        }
        else{
            unsigned char t=pkt->getSndAddress();
            pkt->setDstAddress(t);
            pkt->setSndAddress(address);
            send(pkt->dup(),"vGate$o",0);
        }
        delete pkt;
    }
    else if (msg->arrivedOn("vGate$i")&&(pkt->getSndAddress()==address)){
        bubble("external");
        for (int i=0;i<gateSize("gate$o");i++){
            send(pkt->dup(),"gate$o",i);
        }
        delete pkt;
    }
    else{
        delete pkt;
    }
}
