const unsigned char BROADCAST=255;
const unsigned int RETRANSMIT=10; //sec
const unsigned char MAX_MSG_COUNT=5;
const unsigned int RTS_PORT=12345;
const unsigned int SINK_PORT=12346;
