//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <src/Node.h>
#include "random.h"
#include "routingProtocol.h"
#include "GLOBALS.h"
#include "ApplicationLayer.h"

void Node::initialize(){
    routingProtocol *SAR=new routingProtocol(this,scheduledEvent);
    SAR->address=myAddress=par("addr");
    ApplicationLayer::scheduleNextEvent(this,scheduledEvent);
    networkLayer->RoutingProtocol=SAR;
}

void Node::handleMessage(cMessage *msg){
    if (strcmp("scheduledEvent",msg->getName())==0){
        networkLayer->RoutingProtocol->sendNewPacket(ApplicationLayer::generateData());
        ApplicationLayer::scheduleNextEvent(this,scheduledEvent);
    }
    else{
        Packet *pkt = check_and_cast<Packet *>(msg);
        if (pkt->getDstAddress()==myAddress) {
            networkLayer->RoutingProtocol->handleMyPacket(pkt);
        }
        else{
            networkLayer->RoutingProtocol->handleOverHeard(pkt);
        }
        delete msg;
    }
}
