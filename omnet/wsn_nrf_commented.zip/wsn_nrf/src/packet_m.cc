//
// Generated file, do not edit! Created by nedtool 4.6 from packet.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "packet_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(Packet);

Packet::Packet(const char *name, int kind) : ::cPacket(name,kind)
{
    this->sndAddress_var = 0;
    this->dstAddress_var = 0;
    this->hopCount_var = 0;
    this->msgCount_var = 0;
    for (unsigned int i=0; i<5; i++)
        this->data_var[i] = 0;
    for (unsigned int i=0; i<5; i++)
        this->dataSrc_var[i] = 0;
}

Packet::Packet(const Packet& other) : ::cPacket(other)
{
    copy(other);
}

Packet::~Packet()
{
}

Packet& Packet::operator=(const Packet& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void Packet::copy(const Packet& other)
{
    this->sndAddress_var = other.sndAddress_var;
    this->dstAddress_var = other.dstAddress_var;
    this->hopCount_var = other.hopCount_var;
    this->msgCount_var = other.msgCount_var;
    for (unsigned int i=0; i<5; i++)
        this->data_var[i] = other.data_var[i];
    for (unsigned int i=0; i<5; i++)
        this->dataSrc_var[i] = other.dataSrc_var[i];
}

void Packet::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->sndAddress_var);
    doPacking(b,this->dstAddress_var);
    doPacking(b,this->hopCount_var);
    doPacking(b,this->msgCount_var);
    doPacking(b,this->data_var,5);
    doPacking(b,this->dataSrc_var,5);
}

void Packet::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->sndAddress_var);
    doUnpacking(b,this->dstAddress_var);
    doUnpacking(b,this->hopCount_var);
    doUnpacking(b,this->msgCount_var);
    doUnpacking(b,this->data_var,5);
    doUnpacking(b,this->dataSrc_var,5);
}

unsigned char Packet::getSndAddress() const
{
    return sndAddress_var;
}

void Packet::setSndAddress(unsigned char sndAddress)
{
    this->sndAddress_var = sndAddress;
}

unsigned char Packet::getDstAddress() const
{
    return dstAddress_var;
}

void Packet::setDstAddress(unsigned char dstAddress)
{
    this->dstAddress_var = dstAddress;
}

unsigned char Packet::getHopCount() const
{
    return hopCount_var;
}

void Packet::setHopCount(unsigned char hopCount)
{
    this->hopCount_var = hopCount;
}

unsigned char Packet::getMsgCount() const
{
    return msgCount_var;
}

void Packet::setMsgCount(unsigned char msgCount)
{
    this->msgCount_var = msgCount;
}

unsigned int Packet::getDataArraySize() const
{
    return 5;
}

float Packet::getData(unsigned int k) const
{
    if (k>=5) throw cRuntimeError("Array of size 5 indexed by %lu", (unsigned long)k);
    return data_var[k];
}

void Packet::setData(unsigned int k, float data)
{
    if (k>=5) throw cRuntimeError("Array of size 5 indexed by %lu", (unsigned long)k);
    this->data_var[k] = data;
}

unsigned int Packet::getDataSrcArraySize() const
{
    return 5;
}

unsigned char Packet::getDataSrc(unsigned int k) const
{
    if (k>=5) throw cRuntimeError("Array of size 5 indexed by %lu", (unsigned long)k);
    return dataSrc_var[k];
}

void Packet::setDataSrc(unsigned int k, unsigned char dataSrc)
{
    if (k>=5) throw cRuntimeError("Array of size 5 indexed by %lu", (unsigned long)k);
    this->dataSrc_var[k] = dataSrc;
}

class PacketDescriptor : public cClassDescriptor
{
  public:
    PacketDescriptor();
    virtual ~PacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(PacketDescriptor);

PacketDescriptor::PacketDescriptor() : cClassDescriptor("Packet", "cPacket")
{
}

PacketDescriptor::~PacketDescriptor()
{
}

bool PacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<Packet *>(obj)!=NULL;
}

const char *PacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int PacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 6+basedesc->getFieldCount(object) : 6;
}

unsigned int PacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISEDITABLE,
        FD_ISARRAY | FD_ISEDITABLE,
    };
    return (field>=0 && field<6) ? fieldTypeFlags[field] : 0;
}

const char *PacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "sndAddress",
        "dstAddress",
        "hopCount",
        "msgCount",
        "data",
        "dataSrc",
    };
    return (field>=0 && field<6) ? fieldNames[field] : NULL;
}

int PacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='s' && strcmp(fieldName, "sndAddress")==0) return base+0;
    if (fieldName[0]=='d' && strcmp(fieldName, "dstAddress")==0) return base+1;
    if (fieldName[0]=='h' && strcmp(fieldName, "hopCount")==0) return base+2;
    if (fieldName[0]=='m' && strcmp(fieldName, "msgCount")==0) return base+3;
    if (fieldName[0]=='d' && strcmp(fieldName, "data")==0) return base+4;
    if (fieldName[0]=='d' && strcmp(fieldName, "dataSrc")==0) return base+5;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *PacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "unsigned char",
        "unsigned char",
        "unsigned char",
        "unsigned char",
        "float",
        "unsigned char",
    };
    return (field>=0 && field<6) ? fieldTypeStrings[field] : NULL;
}

const char *PacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int PacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    Packet *pp = (Packet *)object; (void)pp;
    switch (field) {
        case 4: return 5;
        case 5: return 5;
        default: return 0;
    }
}

std::string PacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    Packet *pp = (Packet *)object; (void)pp;
    switch (field) {
        case 0: return ulong2string(pp->getSndAddress());
        case 1: return ulong2string(pp->getDstAddress());
        case 2: return ulong2string(pp->getHopCount());
        case 3: return ulong2string(pp->getMsgCount());
        case 4: return double2string(pp->getData(i));
        case 5: return ulong2string(pp->getDataSrc(i));
        default: return "";
    }
}

bool PacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    Packet *pp = (Packet *)object; (void)pp;
    switch (field) {
        case 0: pp->setSndAddress(string2ulong(value)); return true;
        case 1: pp->setDstAddress(string2ulong(value)); return true;
        case 2: pp->setHopCount(string2ulong(value)); return true;
        case 3: pp->setMsgCount(string2ulong(value)); return true;
        case 4: pp->setData(i,string2double(value)); return true;
        case 5: pp->setDataSrc(i,string2ulong(value)); return true;
        default: return false;
    }
}

const char *PacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    };
}

void *PacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    Packet *pp = (Packet *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}


